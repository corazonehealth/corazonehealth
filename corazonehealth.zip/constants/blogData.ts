const blogData = [
    {
        img: "/assets/blog/stretching-types.jpg",
        date: "September 19, 2024",
        title: "How stretching can improve your heart and increase your life.",
        href: "/blog/september19"
    },
]
export default blogData