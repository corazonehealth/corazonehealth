const brandImages = [
    {
        src: '/assets/img/brands/brand-1.png',
        href: ''
    },
    {
        src: '/assets/img/brands/brand-2.png',
        href: ''
    },
    {
        src: '/assets/img/brands/brand-3.png',
        href: ''
    },
    {
        src: '/assets/img/brands/brand-4.png',
        href: ''
    },
    {
        src: '/assets/img/brands/brand-5.png',
        href: ''
    },
]

export default brandImages