const testimonialData = [
    {
        img: "/assets/img/testimonial/lucy.jpg",
        message: `Lorem ipsum, 
        dolor sit amet consectetur adipisicing elit. 
        Aperiam aliquam.`,
        name: "Lucy Anthony",
    },
    {
        img: "/assets/img/testimonial/michael.jpg",
        message: `Lorem ipsum, 
        dolor sit amet consectetur adipisicing elit. 
        Aperiam aliquam.`,
        name: "Michael Smith",
    },
    {
        img: "/assets/img/testimonial/maria.jpg",
        message: `Lorem ipsum, 
        dolor sit amet consectetur adipisicing elit. 
        Aperiam aliquam.`,
        name: "Maria Garcia",
    },
    {
        img: "/assets/img/testimonial/lucy.jpg",
        message: `Lorem ipsum, 
        dolor sit amet consectetur adipisicing elit. 
        Aperiam aliquam.`,
        name: "Lucy Anthony",
    },
    {
        img: "/assets/img/testimonial/michael.jpg",
        message: `Lorem ipsum, 
        dolor sit amet consectetur adipisicing elit. 
        Aperiam aliquam.`,
        name: "Michael Smith",
    },
    {
        img: "/assets/img/testimonial/maria.jpg",
        message: `Lorem ipsum, 
        dolor sit amet consectetur adipisicing elit. 
        Aperiam aliquam.`,
        name: "Maria Garcia",
    },

]


export default testimonialData