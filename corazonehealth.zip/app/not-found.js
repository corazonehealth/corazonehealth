export const runtime = 'edge';

const NotFound = () => {
    return <div>Page Not Found</div>;
};

export default NotFound;