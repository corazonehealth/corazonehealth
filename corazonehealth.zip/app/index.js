export const runtime = 'edge';

const HomePage = () => {
    return <div>Welcome to My App!</div>;
};

export default HomePage;